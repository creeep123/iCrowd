import React, { useState } from 'react'
import CardList from '../component/CardList'
import { Input } from 'antd';

// const { Search } = Input;

const Pricing = (props) => {
    // const [searchTerm, setSearchTerm] = useState('')
    // const onSearchChange = (e) => {
    //     setSearchTerm(e.target.value)
    // }

    return (<>
        <h1>Pricing Page</h1>
        {/* <CardList searchStaff={searchTerm} /> */}
    </>)
}
export default Pricing